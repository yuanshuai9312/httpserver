﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetClient
{
    public class FileSendClass
    {
        public void SendStart(string IP, string Port, string FilePath, string PackCount, string LastPackSize, string PackSize)
        {

        }

    }
}
